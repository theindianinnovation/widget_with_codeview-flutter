import 'package:flutter/material.dart';

class Iconexample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Icon(
        Icons.home,
        size: 75.0,
        color: Colors.white,
      ),
    );
  }
}
